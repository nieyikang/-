<div align="center"><img width="200" src="https://gitee.com/chu1204505056/vue-admin-beautiful/raw/master/src/colorfulIcon/svg/vab.svg"/>
<h1> vue-admin-beautiful </h1>
<h3>一款基于 vue+element-ui 的绝佳的通用型、中后台前端框架</h3>
<h3>An excellent general-purpose, middle and background front-end framework based on Vue + element UI</h3>
</div>

[![](https://img.shields.io/github/stars/chuzhixin/vue-admin-beautiful?style=flat-square&label=Stars&logo=github)
](https://github.com/chuzhixin/vue-admin-beautiful)

## 演示地址

### - [🚀 演示地址：vue-admin-beautiful （横向纵向布局无缝切换）](https://chu1204505056.gitee.io/vue-admin-beautiful/?hmsr=%E6%8F%92%E4%BB%B6%E5%B8%82%E5%9C%BA&hmpl=&hmcu=&hmkw=&hmci=)

### - [🚀 vue-admin-beautiful-pro 版演示地址](https://chu1204505056.gitee.io/vue-admin-beautiful-pro/?hmsr=%E6%8F%92%E4%BB%B6%E5%B8%82%E5%9C%BA&hmpl=&hmcu=&hmkw=&hmci=)

### - [🚀 vue-admin-beautiful-pro 版演示地址](http://beautiful.panm.cn/vue-admin-beautiful-pro/?hmsr=%E6%8F%92%E4%BB%B6%E5%B8%82%E5%9C%BA&hmpl=&hmcu=&hmkw=&hmci=)

### - [🚀 unicloud 版下载地址](https://ext.dcloud.net.cn/plugin?id=2327)

## vue-admin-beautiful 前端讨论群-1 972435319

不管您加或者不加，您都可以享受到开源的代码，感谢您的支持和信任，群内提供 vue-admin-beautiful-template 基础版本和详细的基础使用文档适合框架快速入门

![img](https://chu1204505056.gitee.io/byui-bookmarks/img/ewm.png)

## 安装

```bash
# 克隆项目
git clone https://github.com/chuzhixin/vue-admin-beautiful.git
# 进入项目目录
npm vue-admin-beautiful
# 安装依赖
npm i
# 本地开发 启动项目
cnpm run serve
```

#### github 标星增长量统计

[![Stargazers over time](https://starcharts.herokuapp.com/chuzhixin/vue-admin-beautiful.svg)](https://github.com/chuzhixin/vue-admin-beautiful)

#### 开发者评级

[![chuzhixin's github stats](https://github-readme-stats.vercel.app/api?username=chuzhixin)](https://github.com/chuzhixin/vue-admin-beautiful)
