import { Custom, Flv, Hls, Mp4 } from "zx-player";

const VabPlayerMp4 = Mp4;
const VabPlayerHls = Hls;
const VabPlayerFlv = Flv;
const VabPlayerCustom = Custom;
export { VabPlayerMp4, VabPlayerHls, VabPlayerFlv, VabPlayerCustom };
