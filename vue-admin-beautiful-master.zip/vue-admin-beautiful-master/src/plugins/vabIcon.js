import Vue from "vue";
import VabIcon from "zx-icon";

Vue.component("vab-icon", VabIcon);
