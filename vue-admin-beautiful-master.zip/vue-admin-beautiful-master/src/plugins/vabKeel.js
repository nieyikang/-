import { Heading, Img, Keel, Text } from "zx-keel";
import "zx-keel/dist/zx-keel.css";

const VabKeel = Keel;
const VabKeelHeading = Heading;
const VabKeelImg = Img;
const VabKeelText = Text;
export { VabKeel, VabKeelHeading, VabKeelImg, VabKeelText };
