import VabComparison from "zx-comparison";

export default VabComparison;
