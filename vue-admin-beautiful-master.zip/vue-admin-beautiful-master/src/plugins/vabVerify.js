import VabVerify from "zx-verify";
import "zx-verify/dist/zx-verify.css";

export default VabVerify;
