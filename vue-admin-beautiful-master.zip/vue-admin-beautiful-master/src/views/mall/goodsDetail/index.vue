<template>
  <div class="goodsDetail-container"></div>
</template>

<script>
  export default {
    name: "GoodsDetail",
    data() {
      return {};
    },
    created() {},
    methods: {},
  };
</script>
